
from mininet.topo import Topo

class MyTopo( Topo ):
    "Simple topology example."

    def __init__( self ):
        "Create custom topo."

        # Initialize topology
        Topo.__init__( self )

        # Add hosts and switches
	H1 = self.addHost( 'h1' )
	H2 = self.addHost( 'h2' )
	H3 = self.addHost( 'h3' )
	H4 = self.addHost( 'h4' )        
	S1 = self.addHost( 's1' )
	S2 = self.addHost( 's2' )
	S22 = self.addSwitch( 's22' )	

        # Add links
        self.addLink( H1, S22 )
        self.addLink( H2, S22 )
        self.addLink( H3, S22 )
        self.addLink( H4, S22 )
        self.addLink( S1, S22 )
        self.addLink( S2, S22 )
	

topos = { 'mytopo': ( lambda: MyTopo() ) }

